# Self-balance-bot-using-controllers
Self balance bot made in PyBullet using PID and LQR controllers, control-dynamics project 
## Introduction 
Hi, I'm Ayush Agarwal , electronics engineering student at IIT BHU Varanasi . This is a project which I made in Control and Dynamics camp of robotics summer camp held by IIT BHU . It is based on the principles of Control Theory . The project consists of 2 self balancing bots made in pybullet , a physics simulation engine , the bots are using PID and LQR controllers respectively .
This project is actually a combination of 2 different projects , which I have described in their respective files .


![image](https://user-images.githubusercontent.com/86561124/138930382-11f38c48-5a62-47a0-a106-67930d0f0304.png)

![image](https://user-images.githubusercontent.com/86561124/138933809-72e67c0f-8a2a-4f37-ae25-d67ffb771b33.png)

![image](https://user-images.githubusercontent.com/86561124/138933943-85fe47fe-dace-4b8a-a3a3-aa1775874e8e.png)

