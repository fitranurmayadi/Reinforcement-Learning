# Self Balance Bot using Reinforcement Learning 
## Introduction 
This project was made as a part of robot learning camp of the robotics summer camp of IIT BHU Varanasi . In this project , I have made a gym environment for the self balance bot 
,set the state variables, reward function etc and then used STABLE BASELINES to use DQN algorithm to train the agent to balance itself in the pybullet environment . 

(PS : https://github.com/Robotics-Club-IIT-BHU/RoL-SummerCamp21/tree/main/Week-3 )

(Stable Baselines Documentation : https://stable-baselines.readthedocs.io/en/master/ )
