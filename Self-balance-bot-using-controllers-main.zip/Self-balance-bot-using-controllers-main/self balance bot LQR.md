# Self Balance bot using LQR controller 
This project is implementation of an LQR controller to make a 2 wheeled bot balance itself by moving around .

This project was implemented as solution to the problem statment presented to us in the week 2 of controls dynamics camp , robotics summer camp IIT BHU Varanasi . 
(PS: https://github.com/Robotics-Club-IIT-BHU/CnD-SummerCamp21/tree/master/Week%202/Challenge%20of%20The%20Week )

The details about the working of the LQR controller are explained on this site very well : https://github.com/Robotics-Club-IIT-BHU/CnD-SummerCamp21/tree/master/Week%202/SubPart%203

The rest of the details can be observed from the code given in the code file on this repository .
